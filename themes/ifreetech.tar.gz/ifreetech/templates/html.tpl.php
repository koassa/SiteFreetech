<!DOCTYPE html>
<html  lang="fr">
<head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="KOASSA" >
    <link rel="icon" href="http://127.0.0.1:8000/favicon.ico">
<!-- Bootstrap core CSS -->
   <?php print $styles; ?>

        <title> Institut Free Tech :: Accueil</title>
   
<style type="text/css">
.row{
  margin-bottom: 15px;
}
</style>
   
  </head>
<!-- NAVBAR style="border:2px solid red"
================================================== -->
  <body>
    <div class="container" >
	<?php print $page_top ?>
 	 <?php print $page ?>
 	<?php print $page_bottom ?>
   

  </body>
</html>
