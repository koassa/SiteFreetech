<div id="node-<?php print $node->nid; ?>" class="post <?php print $classes; ?> clearfix"<?php print $attributes; ?>>
  <h2 class="title"><a href="#"><?php print $title ?></a></h2>
</div>

