  <?php print "Je suis le nouveau template !"; ?>
  <form class=" navbar-left form-inline" role="search">

  <div class="row ">

    <div class="col-md-12">

    <div class="input-group">

      <input type="text" class="form-control" placeholder="Recherche">

      <span class="input-group-btn">

        <button class="btn btn-default" type="button">OK</button>

      </span>

    </div>
  </div>
</div>

</form>
